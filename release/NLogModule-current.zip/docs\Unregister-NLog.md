---
external help file: NLogModule-help.xml
online version: https://github.com/nlog/NLog/wiki/Configuration-file
schema: 2.0.0
---

# Unregister-NLog

## SYNOPSIS
UnRegister the NLog Target..

## SYNTAX

```
Unregister-NLog
```

## DESCRIPTION
UnRegister the NLog Target..

## EXAMPLES

### -------------------------- EXEMPLE 1 --------------------------
```
UnRegister-NLog
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

